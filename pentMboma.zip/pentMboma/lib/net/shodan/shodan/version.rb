module Shodan
  Version = VERSION = '0.2.0'
end
